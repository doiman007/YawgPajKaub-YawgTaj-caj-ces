/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback } from 'react';
import { Toaster, toast } from 'sonner';
import confetti from 'canvas-confetti';
import { Member, Relationship, FamilyData, RelationshipType } from './types';
import { fetchFamilyData, addMember, addRelationship, updateMember } from './lib/api';
import Sidebar from './components/Sidebar/Sidebar';
import TreeCanvas from './components/FamilyTree/TreeCanvas';
import ProfilePanel from './components/Profile/ProfilePanel';
import MemberModal from './components/MemberModal';
import AddRelationshipModal from './components/AddRelationshipModal';

export default function App() {
  const [data, setData] = useState<FamilyData>({ members: [], relationships: [] });
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [isMemberModalOpen, setIsMemberModalOpen] = useState(false);
  const [memberToEdit, setMemberToEdit] = useState<Member | null>(null);
  const [relativeAnchorMember, setRelativeAnchorMember] = useState<Member | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(true); // Default to admin for now as requested

  // Relationship addition state
  const [isRelModalOpen, setIsRelModalOpen] = useState(false);
  const [relCandidate, setRelCandidate] = useState<{ source: Member; target: Member } | null>(null);

  const loadData = useCallback(async () => {
    try {
      const result = await fetchFamilyData();
      setData(result);
    } catch (err) {
      toast.error('ไม่สามารถโหลดข้อมูลได้');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleMemberModalSubmit = async (newMemberData: any) => {
    try {
      const { relationshipToAnchor, ...cleanMemberData } = newMemberData;

      if (memberToEdit) {
        const updated = await updateMember(memberToEdit.id, cleanMemberData);
        setData(prev => ({
          ...prev,
          members: prev.members.map(m => m.id === updated.id ? updated : m)
        }));
        if (selectedMember?.id === updated.id) {
          setSelectedMember(updated);
        }
        toast.success(`อัปเดตข้อมูล ${updated.name} สำเร็จ`);
      } else {
        const member = await addMember(cleanMemberData);
        setData(prev => ({ ...prev, members: [...prev.members, member] }));
        
        // Handle direct relationship creation
        if (relativeAnchorMember && relationshipToAnchor) {
          const rel = await addRelationship({
            fromId: relativeAnchorMember.id,
            toId: member.id,
            type: relationshipToAnchor
          });
          setData(prev => ({ ...prev, relationships: [...prev.relationships, rel] }));
          toast.success(`เพิ่ม ${member.name} และเชื่อมต่อสัมพันธ์สำเร็จ!`);
          setRelativeAnchorMember(null);
        } else {
          toast.success(`เพิ่ม ${member.name} สำเร็จ!`);
        }

        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#3b82f6', '#ec4899', '#facc15']
        });
      }
    } catch (err) {
      toast.error('เกิดข้อผิดพลาดในการบันทึกข้อมูล');
    }
  };

  const openAddModal = (anchor?: Member) => {
    setMemberToEdit(null);
    setRelativeAnchorMember(anchor || null);
    setIsMemberModalOpen(true);
  };

  const openEditModal = (member: Member) => {
    setMemberToEdit(member);
    setIsMemberModalOpen(true);
  };

  const onRelationshipRequest = (sourceId: string, targetId: string) => {
    const source = data.members.find(m => m.id === sourceId);
    const target = data.members.find(m => m.id === targetId);
    if (source && target) {
      setRelCandidate({ source, target });
      setIsRelModalOpen(true);
    }
  };

  const handleAddRelationship = async (type: RelationshipType) => {
    if (!relCandidate) return;
    try {
      const rel = await addRelationship({
        fromId: relCandidate.source.id,
        toId: relCandidate.target.id,
        type
      });
      setData(prev => ({ ...prev, relationships: [...prev.relationships, rel] }));
      toast.success('เชื่อมต่อความสัมพันธ์สำเร็จ');
      setIsRelModalOpen(false);
      setRelCandidate(null);
    } catch (err) {
      toast.error('ไม่สามารถบันทึกความสัมพันธ์ได้');
    }
  };

  const handlePhotoUpload = async (memberId: string, photoData: string) => {
    try {
      const updated = await updateMember(memberId, { photo: photoData });
      setData(prev => ({
        ...prev,
        members: prev.members.map(m => m.id === updated.id ? updated : m)
      }));
      if (selectedMember?.id === updated.id) {
        setSelectedMember(updated);
      }
      toast.success('อัปเดตรูปโปรไฟล์สำเร็จ');
    } catch (err) {
      toast.error('ไม่สามารถอัปเดตรูปภาพได้');
    }
  };

  if (isLoading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-white text-slate-400 font-medium">
        ( กำลังเตรียมข้อมูลครอบครัว... )
      </div>
    );
  }

  return (
    <div className="h-screen w-screen flex bg-slate-50 overflow-hidden font-sans">
      <Toaster position="top-center" richColors />
      
      {/* LEFT PANEL */}
      <Sidebar 
        members={data.members} 
        onSelectMember={setSelectedMember}
        selectedMemberId={selectedMember?.id || null}
        onAddMemberClick={openAddModal}
      />

      {/* CENTER PANEL */}
      <main className="flex-1 relative">
        {/* Admin Toggle for demonstration */}
        <div className="absolute top-4 right-16 z-20 flex items-center gap-2 bg-white/80 backdrop-blur p-2 rounded-xl border border-slate-100 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase">Admin Mode</span>
          <button 
            onClick={() => setIsAdmin(!isAdmin)}
            className={`w-10 h-5 rounded-full transition-colors relative ${isAdmin ? 'bg-blue-500' : 'bg-slate-200'}`}
          >
            <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${isAdmin ? 'left-6' : 'left-1'}`} />
          </button>
        </div>

        <TreeCanvas 
          data={data} 
          onSelectMember={setSelectedMember} 
          selectedMemberId={selectedMember?.id || null}
          onAddRelationshipRequest={onRelationshipRequest}
        />
      </main>

      {/* RIGHT PANEL - Profile Detail */}
      <ProfilePanel 
        member={selectedMember} 
        relationships={data.relationships}
        allMembers={data.members}
        onClose={() => setSelectedMember(null)}
        onSelectMember={setSelectedMember}
        isAdmin={isAdmin}
        onEditClick={openEditModal}
        onAddRelativeClick={openAddModal}
        onPhotoUpload={handlePhotoUpload}
      />

      {/* MODALS */}
      <MemberModal 
        isOpen={isMemberModalOpen} 
        onClose={() => setIsMemberModalOpen(false)} 
        onSubmit={handleMemberModalSubmit}
        member={memberToEdit}
        anchorMember={relativeAnchorMember}
      />

      <AddRelationshipModal
        isOpen={isRelModalOpen}
        onClose={() => setIsRelModalOpen(false)}
        source={relCandidate?.source || null}
        target={relCandidate?.target || null}
        onSubmit={handleAddRelationship}
      />
    </div>
  );
}


import { FamilyData, Member, Relationship } from '../types';

const API_BASE = '/api';

export function calculateAge(birthDate: string, deathDate?: string): number {
  if (!birthDate) return 0;
  const endDate = deathDate ? new Date(deathDate) : new Date();
  const birth = new Date(birthDate);
  let age = endDate.getFullYear() - birth.getFullYear();
  const m = endDate.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && endDate.getDate() < birth.getDate())) {
    age--;
  }
  return age;
}

export async function fetchFamilyData(): Promise<FamilyData> {
  const response = await fetch(`${API_BASE}/data`);
  if (!response.ok) throw new Error('Failed to fetch data');
  return response.json();
}

export async function addMember(member: Omit<Member, 'id'>): Promise<Member> {
  const response = await fetch(`${API_BASE}/members`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(member),
  });
  if (!response.ok) throw new Error('Failed to add member');
  return response.json();
}

export async function updateMember(id: string, member: Partial<Member>): Promise<Member> {
  const response = await fetch(`${API_BASE}/members/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(member),
  });
  if (!response.ok) throw new Error('Failed to update member');
  return response.json();
}

export async function addRelationship(relationship: Omit<Relationship, 'id'>): Promise<Relationship> {
  const response = await fetch(`${API_BASE}/relationships`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(relationship),
  });
  if (!response.ok) throw new Error('Failed to add relationship');
  return response.json();
}

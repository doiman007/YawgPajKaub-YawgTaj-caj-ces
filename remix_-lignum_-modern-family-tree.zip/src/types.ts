export type RelationshipType = 'parent-child' | 'spouse';

export interface Member {
  id: string;
  name: string;
  gender: 'male' | 'female' | 'other';
  birthDate: string; // ISO format (YYYY-MM-DD)
  deathDate?: string; // ISO format (YYYY-MM-DD)
  graveLocation?: {
    lat: number;
    lng: number;
    address?: string;
  };
  photo: string;
  bio?: string;
}

export interface Relationship {
  id: string;
  fromId: string;
  toId: string;
  type: RelationshipType;
}

export interface FamilyData {
  members: Member[];
  relationships: Relationship[];
}

import { Member, RelationshipType } from '../types';
import { X, Heart, Baby } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AddRelationshipModalProps {
  isOpen: boolean;
  onClose: () => void;
  source: Member | null;
  target: Member | null;
  onSubmit: (type: RelationshipType) => void;
}

export default function AddRelationshipModal({ isOpen, onClose, source, target, onSubmit }: AddRelationshipModalProps) {
  if (!isOpen || !source || !target) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
      <AnimatePresence>
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className="bg-white w-full max-w-sm rounded-[2rem] shadow-2xl p-8 space-y-8"
        >
          <div className="text-center space-y-2">
            <h2 className="text-xl font-black text-slate-900 leading-tight">สร้างความสัมพันธ์ใหม่</h2>
            <p className="text-sm text-slate-500">ระบุประเภทความสัมพันธ์ระหว่าง</p>
          </div>

          <div className="flex items-center justify-center gap-4 py-4">
            <div className="flex flex-col items-center gap-2">
              <img src={source.photo} className="w-14 h-14 rounded-2xl object-cover shadow-lg border-2 border-white" />
              <p className="text-xs font-bold text-slate-600 truncate max-w-[80px]">{source.name}</p>
            </div>
            <div className="h-px w-12 bg-slate-200 relative">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-slate-300" />
            </div>
            <div className="flex flex-col items-center gap-2">
              <img src={target.photo} className="w-14 h-14 rounded-2xl object-cover shadow-lg border-2 border-white" />
              <p className="text-xs font-bold text-slate-600 truncate max-w-[80px]">{target.name}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3">
            <button
              onClick={() => onSubmit('parent-child')}
              className="flex items-center gap-4 p-4 rounded-2xl border-2 border-slate-100 hover:border-blue-500 hover:bg-blue-50 transition-all group text-left"
            >
              <div className="p-3 rounded-xl bg-blue-100 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <Baby size={24} />
              </div>
              <div>
                <p className="font-bold text-slate-900">บิดามารดา - บุตร</p>
                <p className="text-xs text-slate-500">{source.name} เป็นพ่อ/แม่ ของ {target.name}</p>
              </div>
            </button>

            <button
              onClick={() => onSubmit('spouse')}
              className="flex items-center gap-4 p-4 rounded-2xl border-2 border-slate-100 hover:border-pink-500 hover:bg-pink-50 transition-all group text-left"
            >
              <div className="p-3 rounded-xl bg-pink-100 text-pink-600 group-hover:bg-pink-600 group-hover:text-white transition-colors">
                <Heart size={24} />
              </div>
              <div>
                <p className="font-bold text-slate-900">คู่สมรส</p>
                <p className="text-xs text-slate-500">{source.name} และ {target.name} เป็นสามีภรรยา</p>
              </div>
            </button>
          </div>

          <button
            onClick={onClose}
            className="w-full py-3 text-sm font-bold text-slate-400 hover:text-slate-600 transition-colors"
          >
            ยกเลิก
          </button>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

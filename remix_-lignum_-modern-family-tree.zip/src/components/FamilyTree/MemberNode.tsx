import { Handle, Position } from '@xyflow/react';
import { Member } from '../../types';
import { motion } from 'motion/react';
import { calculateAge } from '../../lib/api';

interface MemberNodeProps {
  data: {
    member: Member;
    isSelected: boolean;
  };
}

export default function MemberNode({ data }: MemberNodeProps) {
  const { member, isSelected } = data;

  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className={`
        relative px-4 py-3 rounded-2xl border bg-white shadow-soft transition-all duration-300
        ${isSelected ? 'ring-2 ring-blue-500 border-blue-200' : 'border-slate-200'}
        ${member.gender === 'male' ? 'border-l-4 border-l-blue-400' : ''}
        ${member.gender === 'female' ? 'border-l-4 border-l-pink-400' : ''}
        w-48 flex items-center gap-3
      `}
    >
      {/* Handles for connections */}
      <Handle type="target" position={Position.Top} className="w-2 h-2 !bg-slate-300 !border-none" />
      <Handle type="source" position={Position.Bottom} className="w-2 h-2 !bg-slate-300 !border-none" />
      
      {/* Spouse handles (sides) */}
      <Handle type="source" position={Position.Left} id="spouse-left" className="w-2 h-2 !bg-slate-300 !border-none opacity-0 group-hover:opacity-100" />
      <Handle type="source" position={Position.Right} id="spouse-right" className="w-2 h-2 !bg-slate-300 !border-none opacity-0 group-hover:opacity-100" />
 
      <div className="flex-shrink-0 relative">
        <img
          src={member.photo}
          alt={member.name}
          className={`w-10 h-10 rounded-full object-cover border-2 border-slate-50 ${member.deathDate ? 'grayscale opacity-70' : ''}`}
          referrerPolicy="no-referrer"
        />
        {member.deathDate && (
          <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-slate-400 rounded-full flex items-center justify-center border border-white">
            <span className="text-[7px] text-white font-black">†</span>
          </div>
        )}
        {/* Gender dot badge */}
        <div className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border border-white ${
          member.gender === 'male' ? 'bg-blue-500' : 
          member.gender === 'female' ? 'bg-pink-500' : 
          'bg-slate-400'
        }`} />
      </div>
      <div className="flex flex-col min-w-0">
        <span className="text-sm font-semibold text-slate-900 truncate">{member.name}</span>
        <span className="text-xs text-slate-500 uppercase tracking-tight">
          {calculateAge(member.birthDate, member.deathDate)} ปี
        </span>
      </div>
    </motion.div>
  );
}

import { useMemo, useCallback, useEffect } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  Edge,
  Node,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
  MarkerType,
  Position,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import dagre from 'dagre';
import { FamilyData, Member, Relationship } from '../../types';
import MemberNode from './MemberNode';

const nodeTypes = {
  member: MemberNode,
};

const getLayoutedElements = (nodes: Node[], edges: Edge[], direction = 'TB') => {
  const dagreGraph = new dagre.graphlib.Graph();
  dagreGraph.setDefaultEdgeLabel(() => ({}));

  const nodeWidth = 200;
  const nodeHeight = 80;

  dagreGraph.setGraph({ rankdir: direction, nodesep: 100, ranksep: 100 });

  nodes.forEach((node) => {
    dagreGraph.setNode(node.id, { width: nodeWidth, height: nodeHeight });
  });

  edges.forEach((edge) => {
    dagreGraph.setEdge(edge.source, edge.target);
  });

  dagre.layout(dagreGraph);

  const isHorizontal = direction === 'LR';
  nodes.forEach((node) => {
    const nodeWithPosition = dagreGraph.node(node.id);
    node.targetPosition = isHorizontal ? Position.Left : Position.Top;
    node.sourcePosition = isHorizontal ? Position.Right : Position.Bottom;

    // We are shifting the dagre node position (which is center-based) to top-left
    node.position = {
      x: nodeWithPosition.x - nodeWidth / 2,
      y: nodeWithPosition.y - nodeHeight / 2,
    };
  });

  return { nodes, edges };
};

interface TreeCanvasProps {
  data: FamilyData;
  onSelectMember: (member: Member | null) => void;
  selectedMemberId: string | null;
  onAddRelationshipRequest: (sourceId: string, targetId: string) => void;
}

export default function TreeCanvas({
  data,
  onSelectMember,
  selectedMemberId,
  onAddRelationshipRequest,
}: TreeCanvasProps) {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);

  useEffect(() => {
    const initialNodes: Node[] = data.members.map((m) => ({
      id: m.id,
      type: 'member',
      data: { member: m, isSelected: m.id === selectedMemberId },
      position: { x: 0, y: 0 },
    }));

    const initialEdges: Edge[] = data.relationships.map((r) => ({
      id: r.id,
      source: r.fromId,
      target: r.toId,
      animated: r.type === 'parent-child',
      style: {
        stroke: r.type === 'spouse' ? '#94a3b8' : '#3b82f6',
        strokeWidth: 2,
        strokeDasharray: r.type === 'spouse' ? '5,5' : '0',
      },
      label: r.type === 'spouse' ? 'คู่สมรส' : 'บุตร',
      labelStyle: { fill: '#64748b', fontSize: 10, fontWeight: 500 },
      labelBgPadding: [4, 2],
      labelBgBorderRadius: 4,
      labelBgStyle: { fill: '#f8fafc', fillOpacity: 0.8 },
      markerEnd: r.type === 'parent-child' ? { type: MarkerType.ArrowClosed, color: '#3b82f6' } : undefined,
    }));

    const { nodes: layoutedNodes, edges: layoutedEdges } = getLayoutedElements(initialNodes, initialEdges);
    setNodes([...layoutedNodes]);
    setEdges([...layoutedEdges]);
  }, [data, setNodes, setEdges, selectedMemberId]);

  const onConnect = useCallback(
    (params: Connection) => {
      if (params.source && params.target) {
        onAddRelationshipRequest(params.source, params.target);
      }
    },
    [onAddRelationshipRequest]
  );

  const onNodeClick = useCallback(
    (_: any, node: Node) => {
      const member = data.members.find((m) => m.id === node.id);
      onSelectMember(member || null);
    },
    [data.members, onSelectMember]
  );

  return (
    <div className="w-full h-full bg-slate-50 relative overflow-hidden">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onNodeClick={onNodeClick}
        nodeTypes={nodeTypes}
        fitView
        snapToGrid
        snapGrid={[15, 15]}
      >
        <Background gap={20} color="#e2e8f0" />
        <Controls />
      </ReactFlow>
    </div>
  );
}

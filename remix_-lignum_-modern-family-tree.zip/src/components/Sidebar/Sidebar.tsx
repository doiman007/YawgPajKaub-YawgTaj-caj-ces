import { useState } from 'react';
import { Member } from '../../types';
import { Search, Plus, Users, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { calculateAge } from '../../lib/api';

interface SidebarProps {
  members: Member[];
  onSelectMember: (member: Member) => void;
  selectedMemberId: string | null;
  onAddMemberClick: () => void;
}

export default function Sidebar({ members, onSelectMember, selectedMemberId, onAddMemberClick }: SidebarProps) {
  const [search, setSearch] = useState('');

  const filteredMembers = members.filter(m => 
    m.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="w-80 h-full bg-white border-r border-slate-100 flex flex-col shadow-sm z-10">
      <div className="p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Users size={24} className="text-blue-500" />
            Lignum
          </h1>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onAddMemberClick}
            className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors"
            title="เพิ่มสมาชิก"
          >
            <Plus size={20} />
          </motion.button>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            placeholder="ค้นหาสมาชิก..."
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-100 transition-all font-sans"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-6 space-y-1">
        <AnimatePresence mode="popLayout">
          {filteredMembers.map((member) => (
            <motion.button
              key={member.id}
              layout
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              onClick={() => onSelectMember(member)}
              className={`
                w-full flex items-center gap-3 p-3 rounded-xl transition-all group
                ${selectedMemberId === member.id 
                  ? 'bg-blue-50 text-blue-700' 
                  : 'hover:bg-slate-50 text-slate-600 hover:text-slate-900'}
              `}
            >
              <div className="relative">
                <img
                  src={member.photo}
                  alt={member.name}
                  className={`w-10 h-10 rounded-full object-cover border-2 shadow-sm transition-all ${
                    member.gender === 'male' ? 'border-blue-100 shadow-blue-50' : 
                    member.gender === 'female' ? 'border-pink-100 shadow-pink-50' : 
                    'border-white'
                  } ${member.deathDate ? 'grayscale opacity-70' : ''}`}
                  referrerPolicy="no-referrer"
                />
                {member.deathDate && (
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-slate-400 rounded-full flex items-center justify-center border-2 border-white shadow-sm">
                    <span className="text-[8px] text-white font-bold">†</span>
                  </div>
                )}
              </div>
              <div className="flex-1 text-left min-w-0">
                <p className="text-sm font-semibold truncate">{member.name}</p>
                <p className="text-xs opacity-60 font-medium">
                  {calculateAge(member.birthDate, member.deathDate)} ปี
                  {member.deathDate && <span className="ml-1 text-[10px] uppercase font-bold text-slate-400">(เสียชีวิต)</span>}
                </p>
              </div>
              <ArrowRight 
                size={14} 
                className={`transition-all ${selectedMemberId === member.id ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0'}`} 
              />
            </motion.button>
          ))}
        </AnimatePresence>
        
        {filteredMembers.length === 0 && (
          <div className="py-12 text-center text-slate-400">
            <p className="text-sm">ไม่พบรายชื่อที่ค้นหา</p>
          </div>
        )}
      </div>
    </div>
  );
}

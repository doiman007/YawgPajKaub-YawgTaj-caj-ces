import { Member, Relationship } from '../../types';
import { X, Heart, Users, Calendar, Info, Edit3, Gift, MapPin, Camera } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { calculateAge } from '../../lib/api';
import React, { useRef } from 'react';

const formatThaiDate = (dateStr?: string) => {
  if (!dateStr) return '-';
  const date = new Date(dateStr);
  return date.toLocaleDateString('th-TH', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
};

interface ProfilePanelProps {
  member: Member | null;
  relationships: Relationship[];
  allMembers: Member[];
  onClose: () => void;
  onSelectMember: (member: Member) => void;
  isAdmin?: boolean;
  onEditClick?: (member: Member) => void;
  onAddRelativeClick?: (anchor: Member) => void;
  onPhotoUpload?: (memberId: string, photoData: string) => void;
}

export default function ProfilePanel({ 
  member, 
  relationships, 
  allMembers, 
  onClose, 
  onSelectMember,
  isAdmin,
  onEditClick,
  onAddRelativeClick,
  onPhotoUpload
}: ProfilePanelProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!member) return null;

  const handlePhotoClick = () => {
    if (isAdmin && fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onPhotoUpload) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onPhotoUpload(member.id, reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const relevantRelationships = relationships.filter(
    (r) => r.fromId === member.id || r.toId === member.id
  );

  const getRelativeName = (rel: Relationship) => {
    const relativeId = rel.fromId === member.id ? rel.toId : rel.fromId;
    return allMembers.find((m) => m.id === relativeId)?.name || 'Unknown';
  };

  const getRelativeMember = (rel: Relationship) => {
    const relativeId = rel.fromId === member.id ? rel.toId : rel.fromId;
    return allMembers.find((m) => m.id === relativeId);
  };

  const getRelationshipLabel = (rel: Relationship) => {
    if (rel.type === 'spouse') return 'คู่สมรส';
    if (rel.fromId === member.id) return 'บุตร';
    return 'บิดา/มารดา';
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ x: 400, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: 400, opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className="w-96 h-full bg-white border-l border-slate-100 flex flex-col shadow-2xl z-20 absolute right-0 top-0"
      >
        <div className="relative h-48 bg-slate-100 overflow-hidden">
          <img
            src={member.photo}
            alt={member.name}
            className="w-full h-full object-cover blur-2xl opacity-30 scale-110"
            referrerPolicy="no-referrer"
          />
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-white/80 backdrop-blur-md rounded-full text-slate-600 hover:text-slate-900 shadow-sm z-10"
          >
            <X size={20} />
          </button>
          
          <div className="absolute -bottom-12 left-1/2 -translate-x-1/2 group">
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*"
              onChange={handleFileChange}
            />
            <motion.img
              layoutId={`photo-${member.id}`}
              src={member.photo}
              alt={member.name}
              className="w-24 h-24 rounded-3xl object-cover border-4 border-white shadow-xl"
              referrerPolicy="no-referrer"
            />
            {isAdmin && (
              <button
                onClick={handlePhotoClick}
                className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity text-white"
                title="เปลี่ยนรูปโปรไฟล์"
              >
                <Camera size={24} />
              </button>
            )}
          </div>
        </div>

        <div className="pt-16 px-8 pb-8 flex-1 overflow-y-auto space-y-8">
          <div className="text-center space-y-2 relative">
            {isAdmin && onEditClick && (
              <button
                onClick={() => onEditClick(member)}
                className="absolute -top-4 -right-2 p-2 bg-amber-50 text-amber-600 rounded-xl hover:bg-amber-100 transition-colors shadow-sm border border-amber-100"
                title="แก้ไขข้อมูล"
              >
                <Edit3 size={16} />
              </button>
            )}
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">{member.name}</h2>
            <p className="text-slate-500 font-medium">
              {calculateAge(member.birthDate, member.deathDate)} ปี 
              {member.deathDate ? ' (เสียชีวิต)' : ' • Family Member'}
            </p>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 space-y-1">
              <Gift size={16} className="text-blue-500" />
              <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">วันเกิด</p>
              <p className="text-xs font-bold text-slate-700">{formatThaiDate(member.birthDate)}</p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 space-y-1">
              <Calendar size={16} className={member.deathDate ? "text-slate-400" : "text-emerald-500"} />
              <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                {member.deathDate ? 'อายุรวม' : 'อายุ'}
              </p>
              <p className="text-xs font-bold text-slate-700">{calculateAge(member.birthDate, member.deathDate)} ปี</p>
            </div>
            <div className={`p-3 rounded-2xl border space-y-1 ${
              member.gender === 'male' ? 'bg-blue-50 border-blue-100' : 
              member.gender === 'female' ? 'bg-pink-50 border-pink-100' : 
              'bg-slate-50 border-slate-100'
            }`}>
              <Users size={16} className={
                member.gender === 'male' ? 'text-blue-500' : 
                member.gender === 'female' ? 'text-pink-500' : 
                'text-slate-500'
              } />
              <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">เพศ</p>
              <p className={`text-xs font-bold ${
                member.gender === 'male' ? 'text-blue-700' : 
                member.gender === 'female' ? 'text-pink-700' : 
                'text-slate-700'
              }`}>
                {member.gender === 'male' ? 'ชาย' : member.gender === 'female' ? 'หญิง' : 'อื่นๆ'}
              </p>
            </div>
          </div>

          {member.deathDate && (
            <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-3 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <Calendar size={48} />
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">วันเดือนปีที่เสียชีวิต</p>
                <p className="text-lg font-bold">{formatThaiDate(member.deathDate)}</p>
              </div>
              {member.graveLocation && (member.graveLocation.lat || member.graveLocation.address) && (
                <div className="pt-2 border-t border-slate-700 space-y-2">
                  <div className="flex items-start gap-2">
                    <MapPin size={16} className="text-blue-400 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">สถานที่ตั้งหลุมฝังศพ</p>
                      <p className="text-xs font-medium text-slate-200">{member.graveLocation.address || 'ระบุความพิกัดไว้ด้านล่าง'}</p>
                    </div>
                  </div>
                  {member.graveLocation.lat && member.graveLocation.lng && (
                    <a
                      href={`https://www.google.com/maps?q=${member.graveLocation.lat},${member.graveLocation.lng}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-bold rounded-lg transition-colors"
                    >
                      <MapPin size={12} />
                      ดูแผนที่จริง
                    </a>
                  )}
                </div>
              )}
            </div>
          )}

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Heart size={16} className="text-red-500" />
                ความสัมพันธ์ (Relationships)
              </h3>
              {isAdmin && onAddRelativeClick && (
                <button
                  onClick={() => onAddRelativeClick(member)}
                  className="p-1.5 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors flex items-center gap-1"
                >
                  <Users size={14} />
                  <span className="text-[10px] font-bold uppercase">เพิ่มญาติ</span>
                </button>
              )}
            </div>
            <div className="space-y-2">
              {relevantRelationships.map((rel) => {
                const relative = getRelativeMember(rel);
                return (
                  <button
                    key={rel.id}
                    onClick={() => relative && onSelectMember(relative)}
                    className="w-full flex items-center justify-between p-3 rounded-xl border border-slate-100 hover:border-blue-200 hover:bg-blue-50/30 transition-all group"
                  >
                    <div className="flex items-center gap-3">
                      <img 
                        src={relative?.photo} 
                        className="w-8 h-8 rounded-lg object-cover" 
                        referrerPolicy="no-referrer" 
                      />
                      <div className="text-left">
                        <p className="text-sm font-semibold text-slate-700 group-hover:text-blue-700 transition-colors">
                          {relative?.name}
                        </p>
                        <p className="text-[10px] font-bold text-slate-400 uppercase">
                          {getRelationshipLabel(rel)}
                        </p>
                      </div>
                    </div>
                  </button>
                );
              })}
              {relevantRelationships.length === 0 && (
                <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                  <p className="text-xs text-slate-400">ยังไม่มีข้อมูลความสัมพันธ์</p>
                </div>
              )}
            </div>
          </div>

          {member.bio && (
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Info size={16} className="text-slate-400" />
                ประวัติย่อ
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed bg-slate-50/50 p-4 rounded-2xl italic">
                "{member.bio}"
              </p>
            </div>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

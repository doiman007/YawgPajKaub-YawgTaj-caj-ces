import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { X, UserPlus, Image as ImageIcon, Edit3, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Member } from '../types';

const memberSchema = z.object({
  name: z.string().min(2, 'ชื่อต้องมีความยาวอย่างน้อย 2 ตัวอักษร'),
  gender: z.enum(['male', 'female', 'other']),
  birthDate: z.string().min(1, 'กรุณาระบุวันเดือนปีเกิด'),
  deathDate: z.string().optional(),
  graveLocation: z.object({
    lat: z.coerce.number().optional(),
    lng: z.coerce.number().optional(),
    address: z.string().optional(),
  }).optional(),
  photo: z.string().url('URL รูปภาพไม่ถูกต้อง').or(z.string().length(0)),
  bio: z.string().optional(),
  relationshipToAnchor: z.enum(['parent-child', 'spouse']).optional(),
});

type MemberFormInput = z.input<typeof memberSchema>;
type MemberFormOutput = z.output<typeof memberSchema>;

interface MemberModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: MemberFormOutput) => void;
  member?: Member | null;
  anchorMember?: Member | null;
}

export default function MemberModal({ isOpen, onClose, onSubmit, member, anchorMember }: MemberModalProps) {
  const isEditing = !!member;
  const isAddingRelative = !!anchorMember;
  
  const { register, handleSubmit, formState: { errors, isSubmitting }, reset } = useForm<any>({
    resolver: zodResolver(memberSchema),
  });

  useEffect(() => {
    if (isOpen) {
      if (member) {
        reset({
          name: member.name,
          gender: member.gender,
          birthDate: member.birthDate,
          deathDate: member.deathDate || '',
          graveLocation: {
            lat: member.graveLocation?.lat || '',
            lng: member.graveLocation?.lng || '',
            address: member.graveLocation?.address || '',
          },
          photo: member.photo,
          bio: member.bio || '',
        });
      } else {
        reset({
          name: '',
          gender: 'male',
          birthDate: '',
          deathDate: '',
          graveLocation: { lat: '', lng: '', address: '' },
          photo: '',
          bio: '',
          relationshipToAnchor: 'parent-child',
        });
      }
    }
  }, [isOpen, member, reset]);

  const handleFormSubmit = (data: any) => {
    onSubmit(data as MemberFormOutput);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <AnimatePresence>
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden"
        >
          <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-white sticky top-0">
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              {isEditing ? (
                <>
                  <Edit3 className="text-amber-500" size={24} />
                  แก้ไขข้อมูลสมาชิก
                </>
              ) : (
                <>
                  <UserPlus className="text-blue-500" size={24} />
                  เพิ่มสมาชิกครอบครัว
                </>
              )}
            </h2>
            <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full text-slate-400">
              <X size={20} />
            </button>
          </div>

          <form onSubmit={handleSubmit(handleFormSubmit)} className="p-6 space-y-5">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">ชื่อ-นามสกุล</label>
                <input
                  {...register('name')}
                  className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-100 transition-all font-medium"
                  placeholder="ระบุชื่อ..."
                />
                {errors.name && <p className="text-xs text-red-500 ml-1">{(errors.name as any).message}</p>}
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">เพศ</label>
                <select
                  {...register('gender')}
                  className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-100 transition-all font-medium appearance-none"
                >
                  <option value="male">ชาย</option>
                  <option value="female">หญิง</option>
                  <option value="other">อื่นๆ</option>
                </select>
                {errors.gender && <p className="text-xs text-red-500 ml-1">{(errors.gender as any).message}</p>}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">วันเดือนปีเกิด</label>
                <input
                  type="date"
                  {...register('birthDate')}
                  className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-100 transition-all font-medium"
                />
                {errors.birthDate && <p className="text-xs text-red-500 ml-1">{(errors.birthDate as any).message}</p>}
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">วันเดือนปีที่เสียชีวิต (ถ้ามี)</label>
                <input
                  type="date"
                  {...register('deathDate')}
                  className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-100 transition-all font-medium"
                />
              </div>
            </div>

            <div className="space-y-3 p-4 rounded-2xl bg-slate-50/50 border border-slate-100">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">ข้อมูลหลุมฝังศพ / พิกัด</label>
              <div className="grid grid-cols-2 gap-3">
                <input
                  {...register('graveLocation.lat')}
                  placeholder="ละติจูด (Lat)"
                  className="w-full px-4 py-2 rounded-xl bg-white border border-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-100 transition-all text-sm"
                />
                <input
                  {...register('graveLocation.lng')}
                  placeholder="ลองจิจูด (Lng)"
                  className="w-full px-4 py-2 rounded-xl bg-white border border-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-100 transition-all text-sm"
                />
              </div>
              <input
                {...register('graveLocation.address')}
                placeholder="ชื่อสถานที่ / รายละเอียดที่ตั้ง"
                className="w-full px-4 py-2 rounded-xl bg-white border border-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-100 transition-all text-sm"
              />
            </div>

            {isAddingRelative && (
              <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-100 space-y-3">
                <div className="flex items-center gap-2">
                  <Heart size={16} className="text-blue-500" />
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">ความสัมพันธ์กับ {anchorMember?.name}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <label className="relative flex items-center justify-center p-3 rounded-xl border-2 cursor-pointer transition-all has-[:checked]:bg-blue-600 has-[:checked]:text-white has-[:checked]:border-blue-600 hover:bg-white border-slate-100">
                    <input type="radio" {...register('relationshipToAnchor')} value="parent-child" className="sr-only" />
                    <span className="text-xs font-bold">เป็น "ลูก"</span>
                  </label>
                  <label className="relative flex items-center justify-center p-3 rounded-xl border-2 cursor-pointer transition-all has-[:checked]:bg-pink-600 has-[:checked]:text-white has-[:checked]:border-pink-600 hover:bg-white border-slate-100">
                    <input type="radio" {...register('relationshipToAnchor')} value="spouse" className="sr-only" />
                    <span className="text-xs font-bold">เป็น "คู่สมรส"</span>
                  </label>
                </div>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">URL รูปภาพ (เว้นว่างได้)</label>
              <div className="relative">
                <ImageIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  {...register('photo')}
                  className="w-full pl-12 pr-4 py-3 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-100 transition-all font-medium"
                  placeholder="https://..."
                />
              </div>
              {errors.photo && <p className="text-xs text-red-500 ml-1">{(errors.photo as any).message}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">ประวัติย่อ</label>
              <textarea
                {...register('bio')}
                rows={3}
                className="w-full px-4 py-3 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-100 transition-all font-medium resize-none"
                placeholder="เล่าข้อมูลเล็กน้อย..."
              />
            </div>

            <div className="pt-4 flex gap-3">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-6 py-3 rounded-2xl font-bold text-slate-500 hover:bg-slate-50 transition-colors"
              >
                ยกเลิก
              </button>
              <button
                disabled={isSubmitting}
                className={`flex-[2] px-6 py-3 rounded-2xl text-white font-bold transition-all shadow-lg hover:shadow-xl disabled:opacity-50 ${isEditing ? 'bg-amber-500 hover:bg-amber-600' : 'bg-slate-900 hover:bg-slate-800'}`}
              >
                {isSubmitting ? 'กำลังบันทึก...' : isEditing ? 'บันทึกการแก้ไข' : 'บันทึกสมาชิก'}
              </button>
            </div>
          </form>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
